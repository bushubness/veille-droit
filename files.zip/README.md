# Veille droit français — newsletter 100% autonome

Pipeline qui, chaque matin et sans aucune intervention :
récupère les nouveautés du droit (flux officiels service-public.fr) →
les sélectionne + vulgarise avec Claude → envoie une campagne email à tes abonnés (Brevo).

Tout le code est déjà écrit. Il te reste **4 actions** (créer des comptes + coller des clés).

---

## Étape 1 — GitHub (héberge et lance le robot chaque jour)
1. Crée un compte sur github.com (gratuit).
2. Clique **New repository** → nom : `veille-droit` → coche **Public** → **Create**.
3. **Add file → Upload files** → glisse TOUS les fichiers de ce dossier
   (newsletter.py, requirements.txt, seen.json, et le dossier `.github`).
   → **Commit changes**.

## Étape 2 — Clé Claude (le cerveau)
1. Va sur console.anthropic.com → crée un compte.
2. **Billing** → ajoute un moyen de paiement + un petit crédit (qq € suffisent, ça coûte des centimes/jour).
3. **API keys → Create key** → copie la clé (commence par `sk-ant-`).

## Étape 3 — Brevo (envoi + inscriptions)
1. Va sur brevo.com → crée un compte gratuit (300 emails/jour).
2. **Senders** → ajoute et valide ton email d'expéditeur.
3. **Contacts → Lists → Create a list** → note son **ID** (un nombre).
4. **Contacts → Forms** → crée un formulaire d'inscription → publie le lien
   (c'est CE lien que tu mets dans ta bio / TikTok ; les abonnés s'ajoutent seuls).
5. **SMTP & API → API Keys → Generate** → copie la clé.

## Étape 4 — Coller les clés dans GitHub (Secrets)
Dans ton repo : **Settings → Secrets and variables → Actions → New repository secret**.
Crée ces 5 secrets (un par un) :

| Nom | Valeur |
|-----|--------|
| `ANTHROPIC_API_KEY` | ta clé `sk-ant-...` |
| `BREVO_API_KEY` | ta clé Brevo |
| `BREVO_LIST_ID` | l'ID de ta liste (nombre) |
| `SENDER_EMAIL` | ton email expéditeur validé |
| `SENDER_NAME` | le nom affiché (ex: Le droit en clair) |

---

## C'est fini.
Le robot tourne tout seul chaque matin (05h30 UTC ≈ 7h30 Paris).

**Tester tout de suite** sans attendre demain : onglet **Actions** → *Veille droit quotidienne*
→ **Run workflow**.

Régler l'heure : change la ligne `cron:` dans `.github/workflows/daily.yml`.
Réduire le coût : ajoute un secret `CLAUDE_MODEL` = `claude-haiku-4-5`.
